- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 03-05-2020 a las 21:52:57
-- Versión del servidor: 10.4.11-MariaDB
-- Versión de PHP: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `chrissb`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `banca`
--

CREATE TABLE `banca` (
  `id_banca` int(8) NOT NULL COMMENT '1',
  `DopVivas` int(8) DEFAULT 0,
  `DopCreditos` int(8) DEFAULT 0,
  `USVivas` int(8) DEFAULT 0,
  `USCreditos` int(8) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `banca`
--

INSERT INTO `banca` (`id_banca`, `DopVivas`, `DopCreditos`, `USVivas`, `USCreditos`) VALUES
(1000001, 50000, 30000, 2000, 2000),
(1000002, 400000, 350000, 800, 500),
(1000003, 60000, 30000, 500, 500),
(1000004, 1300000, 1100000, 20000, 15000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fill`
--

CREATE TABLE `fill` (
  `id_fill` int(11) NOT NULL,
  `id_mesajuego` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  `dopVivas` int(11) DEFAULT NULL,
  `dopCredito` int(11) DEFAULT NULL,
  `usVivas` int(11) DEFAULT NULL,
  `usCredito` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mesajuego`
--

CREATE TABLE `mesajuego` (
  `id_MesaJuego` int(6) NOT NULL,
  `nombre` varchar(40) NOT NULL,
  `id_banca` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `mesajuego`
--

INSERT INTO `mesajuego` (`id_MesaJuego`, `nombre`, `id_banca`) VALUES
(1, 'black jack 1', 1000001),
(2, 'Ruleta 1', 1000002),
(6, 'Black jack 2', 1000003),
(10, 'Baccarat 1', 1000004),
(26, 'Ruleta 2', 1000002),
(34, 'Four car 1', 1000002),
(35, 'texas poker 1', 1000003);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reportemesajuego`
--

CREATE TABLE `reportemesajuego` (
  `id_reportemesa` int(6) NOT NULL,
  `id_mesaJuego` int(6) NOT NULL,
  `DopEfectivo` float DEFAULT NULL,
  `USEfectivo` float DEFAULT NULL,
  `MarcaDop` int(8) DEFAULT NULL,
  `MarcaUS` int(8) DEFAULT NULL,
  `Fecha` datetime NOT NULL DEFAULT current_timestamp(),
  `FillDop` int(15) DEFAULT NULL,
  `FillUsa` int(11) DEFAULT NULL,
  `Banca_final_Dop` int(11) DEFAULT NULL,
  `Banca_final_Usa` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `reportemesajuego`
--

INSERT INTO `reportemesajuego` (`id_reportemesa`, `id_mesaJuego`, `DopEfectivo`, `USEfectivo`, `MarcaDop`, `MarcaUS`, `Fecha`, `FillDop`, `FillUsa`, `Banca_final_Dop`, `Banca_final_Usa`) VALUES
(1, 1, 187500, 1050, 40000, NULL, '2020-05-03 00:43:37', 20000, NULL, 450000, 2100);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(6) NOT NULL,
  `nombreUsuario` varchar(30) NOT NULL,
  `contraseña` varchar(20) NOT NULL,
  `Email` varchar(40) NOT NULL,
  `Rol` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nombreUsuario`, `contraseña`, `Email`, `Rol`) VALUES
(1, 'erika10', '123456', 'christopherperez1230@gmail.com', 'gerente');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `banca`
--
ALTER TABLE `banca`
  ADD UNIQUE KEY `uid_banca` (`id_banca`);

--
-- Indices de la tabla `fill`
--
ALTER TABLE `fill`
  ADD PRIMARY KEY (`id_fill`),
  ADD KEY `FK_mesajuego` (`id_mesajuego`);

--
-- Indices de la tabla `mesajuego`
--
ALTER TABLE `mesajuego`
  ADD PRIMARY KEY (`id_MesaJuego`),
  ADD KEY `id_banca` (`id_banca`);

--
-- Indices de la tabla `reportemesajuego`
--
ALTER TABLE `reportemesajuego`
  ADD PRIMARY KEY (`id_reportemesa`),
  ADD KEY `fk_mesajuegoo` (`id_mesaJuego`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `banca`
--
ALTER TABLE `banca`
  MODIFY `id_banca` int(8) NOT NULL AUTO_INCREMENT COMMENT '1', AUTO_INCREMENT=1000005;

--
-- AUTO_INCREMENT de la tabla `fill`
--
ALTER TABLE `fill`
  MODIFY `id_fill` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `mesajuego`
--
ALTER TABLE `mesajuego`
  MODIFY `id_MesaJuego` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT de la tabla `reportemesajuego`
--
ALTER TABLE `reportemesajuego`
  MODIFY `id_reportemesa` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `fill`
--
ALTER TABLE `fill`
  ADD CONSTRAINT `FK_mesajuego` FOREIGN KEY (`id_mesajuego`) REFERENCES `mesajuego` (`id_MesaJuego`);

--
-- Filtros para la tabla `mesajuego`
--
ALTER TABLE `mesajuego`
  ADD CONSTRAINT `mesajuego_ibfk_1` FOREIGN KEY (`id_banca`) REFERENCES `banca` (`id_banca`);

--
-- Filtros para la tabla `reportemesajuego`
--
ALTER TABLE `reportemesajuego`
  ADD CONSTRAINT `fk_mesajuegoo` FOREIGN KEY (`id_mesaJuego`) REFERENCES `mesajuego` (`id_MesaJuego`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
Footer
© 2022 GitHub, Inc.
Footer navigation
Terms
Privacy
Security
Status
Docs
Contact GitHub
