<?php
include ("conexion.php");
$con = conectar();
$id=$_GET['id'];
$sql="delete from mesajuego where id_mesajuego='".$id."'";
mysqli_query($con,$sql);
header("location:vermesajuego.php");
	
?>