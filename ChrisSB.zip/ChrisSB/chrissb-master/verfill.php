
<!DOCTYPE html>
<?php
session_start();
if($_SESSION['validacion'] == 1)
{
    include("conexion.php");
			$con= conectar();
			$sql="SELECT * from fill order by id_fill and fecha";
			$result=mysqli_query($con, $sql);
?>
<html lang="es">
	<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
<link rel="icon" type="image/png" href="../img/tarjetas.png" />
  <title>Chrissl</title>
  <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="../css/sb-admin-2.min.css" rel="stylesheet">
</head>
<body id="page-top">
  <div id="wrapper">
  <?php include("menu.php"); ?>
    <div id="content-wrapper" class="d-flex flex-column">
      <!-- Main Content -->
      <div id="content">
	  <?php include("header_logout.php"); ?>
        <div class="container-fluid">
		  <!-- DataTales Example -->		
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">FILLS</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>ID_fill</th>
                      <th>Fecha</th>
                      <th>Codigo mesa</th>
					  <th>$RD vivas</th>
                      <th>$RD credi</th>
                      <th>$US vivas </th>
					  <th>$US credi</th>
                    </tr>
</thead>
                  <tbody>
                    <?php setlocale(LC_MONETARY, 'en_US'); ?>
                  <?php	while($filas = mysqli_fetch_array($result)){?>
                    
                    <tr>
                        <td><?php echo $filas['id_fill']?></td>
                        <td><?php echo $filas['fecha']?></td>
						            <td><?php echo $filas['id_mesajuego']?></td>
                        <td><?php echo $filas['dopVivas']?></td>
						            <td><?php echo $filas['dopCredito']?></td>
                        <td><?php echo $filas['usVivas']?></td>
						            <td><?php echo $filas['usCredito']?></td>
                    </tr>
				<?php
			}?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
		  
        </div>
      </div>

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Cekira 2020</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
  </div>
  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
    <?php include("footer_logout.php"); ?>
  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="../js/sb-admin-2.min.js"></script>

</body>
</html>
<?php
}else{
	
	header("location:index.php");
}
?>