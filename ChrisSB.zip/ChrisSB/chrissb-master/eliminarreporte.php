<?php
include ("conexion.php");
$con = conectar();
$id=$_GET['id'];
$sql="delete from reportedia where id_reportedia='".$id."'";
mysqli_query($con,$sql);
header("location:vermesajuego.php");
	
?>