<!DOCTYPE html>
<html>
	<head>
	</head>
	<body>
		<ul>Menu:
			<li><a href="#">Actualizar banca</a></li>
			<li><a href="#">Crear reporteMesa</a></li>
			<li><a href="#">Editar reporteMesa</a></li>
			<li><a href="#">Eliminar reporteMesa</a></li>
			<li><a href="#">Ver estado mesa</a></li>
		</ul>
		
	</body>
</html>