/*
 Navicat Premium Data Transfer

 Source Server         : Localhost
 Source Server Type    : MySQL
 Source Server Version : 100132
 Source Host           : localhost:3306
 Source Schema         : chrissb

 Target Server Type    : MySQL
 Target Server Version : 100132
 File Encoding         : 65001

 Date: 08/05/2020 16:41:08
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for banca
-- ----------------------------
DROP TABLE IF EXISTS `banca`;
CREATE TABLE `banca`  (
  `id_banca` int(8) NOT NULL AUTO_INCREMENT COMMENT '1',
  `DopVivas` int(8) NULL DEFAULT 0,
  `DopCreditos` int(8) NULL DEFAULT 0,
  `USVivas` int(8) NULL DEFAULT 0,
  `USCreditos` int(8) NULL DEFAULT 0,
  UNIQUE INDEX `uid_banca`(`id_banca`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1000006 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of banca
-- ----------------------------
INSERT INTO `banca` VALUES (1000001, 50000, 30000, 2000, 2000);
INSERT INTO `banca` VALUES (1000002, 400000, 350000, 800, 500);
INSERT INTO `banca` VALUES (1000003, 60000, 30000, 500, 500);
INSERT INTO `banca` VALUES (1000004, 1300000, 1100000, 20000, 15000);
INSERT INTO `banca` VALUES (1000005, 10000, 5000, 50, 25);

-- ----------------------------
-- Table structure for fill
-- ----------------------------
DROP TABLE IF EXISTS `fill`;
CREATE TABLE `fill`  (
  `id_fill` int(11) NOT NULL AUTO_INCREMENT,
  `id_mesajuego` int(11) NOT NULL,
  `fecha` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dopVivas` int(11) NULL DEFAULT NULL,
  `dopCredito` int(11) NULL DEFAULT NULL,
  `usVivas` int(11) NULL DEFAULT NULL,
  `usCredito` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id_fill`) USING BTREE,
  INDEX `FK_mesajuego`(`id_mesajuego`) USING BTREE,
  CONSTRAINT `FK_mesajuego` FOREIGN KEY (`id_mesajuego`) REFERENCES `mesajuego` (`id_MesaJuego`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of fill
-- ----------------------------
INSERT INTO `fill` VALUES (2, 1, '2020-05-03 20:09:15', 544444, 1212, 1221, 334);
INSERT INTO `fill` VALUES (3, 1, '2020-05-03 21:25:40', 4455, 7899, 454567, 78898);
INSERT INTO `fill` VALUES (4, 10, '2020-05-04 22:50:48', 50000, 0, 0, 0);
INSERT INTO `fill` VALUES (5, 38, '2020-05-07 22:44:47', 20000, 15000, 200, 100);

-- ----------------------------
-- Table structure for mesajuego
-- ----------------------------
DROP TABLE IF EXISTS `mesajuego`;
CREATE TABLE `mesajuego`  (
  `id_MesaJuego` int(6) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `id_banca` int(11) NOT NULL,
  PRIMARY KEY (`id_MesaJuego`) USING BTREE,
  INDEX `id_banca`(`id_banca`) USING BTREE,
  CONSTRAINT `mesajuego_ibfk_1` FOREIGN KEY (`id_banca`) REFERENCES `banca` (`id_banca`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 39 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of mesajuego
-- ----------------------------
INSERT INTO `mesajuego` VALUES (1, 'black jack 1', 1000001);
INSERT INTO `mesajuego` VALUES (2, 'Ruleta 1', 1000002);
INSERT INTO `mesajuego` VALUES (6, 'Black jack 2', 1000003);
INSERT INTO `mesajuego` VALUES (10, 'Baccarat 1', 1000004);
INSERT INTO `mesajuego` VALUES (26, 'Ruleta 2', 1000002);
INSERT INTO `mesajuego` VALUES (34, 'Four car 1', 1000002);
INSERT INTO `mesajuego` VALUES (35, 'texas poker 1', 1000003);
INSERT INTO `mesajuego` VALUES (37, 'black jack loco 1', 1000002);
INSERT INTO `mesajuego` VALUES (38, 'Reporte no1', 1000005);

-- ----------------------------
-- Table structure for reportemesajuego
-- ----------------------------
DROP TABLE IF EXISTS `reportemesajuego`;
CREATE TABLE `reportemesajuego`  (
  `id_reportemesa` int(6) NOT NULL AUTO_INCREMENT,
  `id_mesaJuego` int(6) NOT NULL,
  `efectivod` int(11) NULL DEFAULT NULL,
  `efectivou` int(11) NULL DEFAULT NULL,
  `marcad` int(8) NULL DEFAULT NULL,
  `marcau` int(8) NULL DEFAULT NULL,
  `Fecha` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `filld` int(15) NULL DEFAULT NULL,
  `fillu` int(11) NULL DEFAULT NULL,
  `bancad` int(11) NULL DEFAULT NULL,
  `bancau` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id_reportemesa`) USING BTREE,
  INDEX `fk_mesajuegoo`(`id_mesaJuego`) USING BTREE,
  CONSTRAINT `fk_mesajuegoo` FOREIGN KEY (`id_mesaJuego`) REFERENCES `mesajuego` (`id_MesaJuego`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of reportemesajuego
-- ----------------------------
INSERT INTO `reportemesajuego` VALUES (1, 1, 187500, 1050, 40000, NULL, '2020-05-03 00:43:37', 20000, NULL, 450000, 2100);
INSERT INTO `reportemesajuego` VALUES (2, 34, 31300, 50, 10000, 0, '2020-05-04 22:56:26', 0, 0, 130000, 155);
INSERT INTO `reportemesajuego` VALUES (3, 34, 31300, 50, 10000, 0, '2020-05-05 22:57:04', 0, 0, 130000, 155);
INSERT INTO `reportemesajuego` VALUES (4, 1, 187500, 1050, 40000, NULL, '2020-05-06 00:43:37', 20000, NULL, 550000, 2100);
INSERT INTO `reportemesajuego` VALUES (5, 34, 31300, 50, 10000, 0, '2020-05-07 22:56:26', 0, 0, 160000, 155);
INSERT INTO `reportemesajuego` VALUES (6, 34, 31300, 50, 10000, 0, '2020-05-08 22:57:04', 0, 0, 180000, 155);
INSERT INTO `reportemesajuego` VALUES (7, 38, 1, 2, 3, 4, '2020-04-26 22:52:18', 35000, 300, 15000, 75);
INSERT INTO `reportemesajuego` VALUES (8, 1, 190000, 500, 90000, NULL, '2020-04-27 00:43:37', 90000, 1, 450000, 2100);
INSERT INTO `reportemesajuego` VALUES (9, 34, 200000, 400, 80000, 0, '2020-04-28 22:56:26', 80000, 2, 130000, 155);
INSERT INTO `reportemesajuego` VALUES (10, 34, 175000, 300, 70000, 0, '2020-04-29 22:57:04', 70000, 3, 130000, 155);
INSERT INTO `reportemesajuego` VALUES (11, 1, 155000, 200, 60000, NULL, '2020-04-30 00:43:37', 60000, 4, 550000, 2100);
INSERT INTO `reportemesajuego` VALUES (12, 34, 90000, 100, 50000, 0, '2020-05-01 22:56:26', 50000, 5, 160000, 155);
INSERT INTO `reportemesajuego` VALUES (13, 34, 60000, 50, 30000, 0, '2020-05-02 22:57:04', 30000, 6, 180000, 155);
INSERT INTO `reportemesajuego` VALUES (14, 38, 20000, 10, 20000, 4, '2020-05-07 22:52:18', 20000, 300, 15000, 75);

-- ----------------------------
-- Table structure for usuario
-- ----------------------------
DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario`  (
  `id_usuario` int(6) NOT NULL AUTO_INCREMENT,
  `nombreUsuario` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `pass` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Email` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `roles` int(3) NOT NULL,
  PRIMARY KEY (`id_usuario`) USING BTREE,
  INDEX `fk_roles`(`roles`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of usuario
-- ----------------------------
INSERT INTO `usuario` VALUES (1, 'admin', '123456', 'christopherperez1230@gmail.com', 1);
INSERT INTO `usuario` VALUES (2, 'diomedes01', 'tito10', 'diomedes@gmail.com', 2);
INSERT INTO `usuario` VALUES (3, 'erika10', 'tito12', 'erikacaraballo@gmail.com', 3);

-- ----------------------------
-- View structure for vw_dashboard_pie
-- ----------------------------
DROP VIEW IF EXISTS `vw_dashboard_pie`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`localhost` SQL SECURITY DEFINER VIEW `vw_dashboard_pie` AS select 
MONTH(fecha) as mes,
(
 sum(efectivod)
 ) as dineroDOP,
(
  sum(efectivou)
 ) as dineroUS,
(
  sum(filld)
 ) as fill_dineroDOP,
(
  sum(fillu)
 ) as fill_dineroUS,
 (
  sum(bancad)
 ) as bancaDOP,
 (
  sum(bancau)
 ) as bancaUS
 from reportemesajuego
 GROUP BY
 MONTH(fecha) ;

-- ----------------------------
-- View structure for vw_new_reporte
-- ----------------------------
DROP VIEW IF EXISTS `vw_new_reporte`;
CREATE ALGORITHM = UNDEFINED DEFINER = `root`@`localhost` SQL SECURITY DEFINER VIEW `vw_new_reporte` AS select
m.id_MesaJuego,
m.nombre as nombre_mesa,
b.id_banca,
 (
 b.DopVivas + b.DopCreditos
 ) as dineroDOP,
(
 b.USVivas + b.DopCreditos
 ) as dineroUS,
(
 f.dopVivas + f.dopCredito
 ) as fill_dineroDOP,
(
 f.usVivas + f.usCredito
 ) as fill_dineroUS

from mesajuego as m
join banca as b on b.id_banca = m.id_banca
left join fill as f on f.id_mesajuego = m.id_MesaJuego
-- 1000005
GROUP BY m.id_MesaJuego ;

SET FOREIGN_KEY_CHECKS = 1;
