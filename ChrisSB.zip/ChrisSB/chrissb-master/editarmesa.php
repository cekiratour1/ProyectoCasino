
<!DOCTYPE html>
<?php
session_start();
if($_SESSION['validacion'] == 1)
{
    include ("conexion.php");
$con = conectar();
$id=$_GET['id'];
$sql="select * from mesajuego where id_mesajuego='".$id."'";
$result=mysqli_query($con,$sql);
$bank;
?>
<html lang="es">
	<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
	<link rel="icon" type="image/png" href="../img/tarjetas.png" />
  <title>Cekira</title>
  <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="../css/sb-admin-2.min.css" rel="stylesheet">
</head>
<body id="page-top">
  <div id="wrapper">
 	 <?php include("menu.php"); ?>
    <div id="content-wrapper" class="d-flex flex-column">
      <!-- Main Content -->
      <div id="content">
          <!-- Topbar -->
		  <?php include("header_logout.php"); ?>
        <div class="container-fluid">
		<?php		
		  while($fila=mysqli_fetch_array($result)){	
            ?>
            <form method="post">
                <div class="form-group">	
                    <input type="hidden" name="txtid" value="<?php echo $fila['id_mesajuego'] ?>">
                    <label for="exampleInputEmail1">Nombre de la mesa:</label>
                    <input disabled="true" name="nombre" type="text" placeholder="nombre mesa" class="form-control" aria-describedby="emailHelp" required value="<?php echo $fila['nombre'] ?>">
                    <label for="exampleInputEmail1">Código banca:</label>
                    <input disabled="true" name="idbanka" type="text"class="form-control"  required value="<?php echo $fila['id_banca'] ?>">
                </div>             
            </form>
			<?php
			
            $bank=$fila['id_banca'];
            }            
            $sql2="select * from banca where id_banca='".$bank."'";
			$result2=mysqli_query($con,$sql2);			
            while($filas=mysqli_fetch_array($result2)){	
            ?>
		    <form method="post" name ="form2">
                <div class="form-group">	
                    <input type="hidden" name="txtid2" value="<?php echo $filas['id_banca'] ?>">
                    <label>Fichas Dopvivas:</label>
                    <input class="form-control" aria-describedby="emailHelp" name="Dviva" type="number" required value="<?php echo $filas['DopVivas'] ?>">
                    <label>Fichas DopCreditos:</label>
                    <input class="form-control" aria-describedby="emailHelp" name="Dcredi" type="number" required value="<?php echo $filas['DopCreditos'] ?>">
                    <label>Fichas USvivas:</label>
                    <input class="form-control" aria-describedby="emailHelp" name="Uviva" type="number" required value="<?php echo $filas['USVivas'] ?>">
                    <label>Fichas USCreditos:</label>
                    <input class="form-control" aria-describedby="emailHelp" name="Ucredi" type="number" required value="<?php echo $filas['USCreditos'] ?>">
                </div>
                <div class="form-check">
                    <a href="vermesajuego.php" class="btn btn-danger btn-icon-split">
                        <span class="icon text-white-50">
                        <i class="fas fa-trash"></i>
                        </span>
                        <span class="text">Regresar</span>
                    </a>
				    <button type="submit" class="btn btn-success btn-icon-split">
						<span class="icon text-white-50">		  
						<i class="fas fa-check"></i>
                    	</span>
						<span class="text">Actualizar</span>
					</button>
			    </div>
            </form>
            <?php 
            }	
				if(isset($_POST['txtid2']))
				{ 						
                    $Dviva=$_POST['Dviva'];
                    $Dcredi=$_POST['Dcredi'];
                    $Uviva=$_POST['Uviva'];
					$Ucredi=$_POST['Ucredi'];					
					$sql3 = "update banca set DopVivas = '".$Dviva."', DopCreditos = '".$Dcredi."', USVivas = '".$Uviva."', USCreditos= '".$Ucredi."' where id_banca='".$bank."'";
					var_dump( $sql3 );
					mysqli_query($con, $sql3);
					echo '<script>window.location="vermesajuego.php"</script>';
					// header("location:vermesajuego.php");
            	}
            ?>
        </div>
      </div>
	  <?php include("footer.php"); ?>

    </div>
  </div>
  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  	<?php include("footer_logout.php"); ?>

  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="../js/sb-admin-2.min.js"></script>

</body>
</html>
<?php
}
else{
	
	header("location:index.php");
}
?>