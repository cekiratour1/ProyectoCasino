<!DOCTYPE html>
<?php
session_start();
if($_SESSION['validacion'] == 1)
{

			include("conexion.php");
			$con= conectar();
			$sql="SELECT id_banca from banca";
			$result=mysqli_query($con,$sql);
		?>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>SB Admin 2 - Charts</title>

  <!-- Custom fonts for this template-->
  <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="../css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <?php include("menu.php"); ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

     <?php include("header_logout.php"); ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Dashboard</h1>

          <!-- Content Row -->
          <div class="row">

            <div class="col-xl-7 col-lg-7">
              <!-- Bar Chart -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Dashboard Diario</h6>
                </div>
                <div class="card-body">
                  <div class="chart-bar">
                    <!-- <canvas id="myBarChart"></canvas> -->
                    <canvas id="bar-chart" width="800" height="450"></canvas>
                  </div>
                </div>
              </div>
            </div>

            <!-- Donut Chart -->
            <div class="col-xl-5 col-lg-5">
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Dashboard Mensual</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                  <div class="chart-pie pt-4">
                    <!-- <canvas id="myPieChart"></canvas> -->
                    <canvas id="pie-chart"></canvas>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <?php include("footer.php"); ?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <?php include("footer_logout.php"); ?>

  <!-- Bootstrap core JavaScript-->
  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="../js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="../vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <!-- <script src="../js/demo/chart-area-demo.js"></script> -->
  <!-- <script src="../js/demo/chart_pie.js"></script> -->
  <!-- <script src="../js/demo/chart-bar-demo.js"></script> -->
  <script src="../js/demo/chart_bar.js"></script>
  <script type="text/javascript">			
		Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
    Chart.defaults.global.defaultFontColor = '#858796';
    var result_pie = null;
    var data_pie = [];
    $( document ).ready(function() {
      $.ajax({
					url:   'search.php?pie=1',
					type:  'get',
					success:  function (data) {
						// result_pie = eval("("+data+")");
            result_pie = JSON.parse(data);
            // console.log(result_pie);
            var itt = '';
            // for (var it = 0; it < 12; it++){
              // for (var i in result_pie){
            //     if (it == itt){
            //       data_pie[it] = 0;
            //     // console.log(it);
            //     // data_pie[i] = result_pie[i].bancaDOP;
            //     itt = it;
            //   } 
            //   else {
            //     console.log(it,itt,result_pie[it]);
            //     data_pie[it] = result_pie[itt].bancaDOP;
                
            //   }
            //   // }
                
            // }
            // Pie Chart Example
    var ctx = document.getElementById("pie-chart");
    console.log(data_pie);
    var myPieChart = new Chart(ctx, {
      type: 'pie',
      data: {
        labels: ["Enero", "Febrero", "Marzo","Abril", "Mayo", "Junio","Julio", "Agosto", "Septiembre","Octubre", "Noviembre", "Diciembre"],
        datasets: [{
          data: [5, 10, 15,20,25,30,35,40,45,50,55,60],
          backgroundColor: ['#14ADEA', '#0A5471', '#36b9cc','#B21EA4','#5B08EC','#09A0C6','#13CA3A','#9FE116','#E1DB16','#D07F0B','#D03E0B','#EC150E'],
          hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf','#500849','#362650','#324A50','#065D18','#486805','#6D6A09','#6D4409','#5D2410','#64201D'],
          hoverBorderColor: "rgba(234, 236, 244, 1)",
        // },
        // {
        //     data: [65, 40, 25],
        //     backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc'],
        //     hoverBackgroundColor: ['#0AD877', '#0B7E48', '#2c9faf'],
        //     hoverBorderColor: "rgba(234, 236, 244, 1)",
          }
        ],
      },
      options: {
        maintainAspectRatio: false,
        tooltips: {
          backgroundColor: "rgb(255,255,255)",
          bodyFontColor: "#858796",
          borderColor: '#dddfeb',
          borderWidth: 1,
          xPadding: 15,
          yPadding: 15,
          displayColors: false,
          caretPadding: 10,
        },
        legend: {
          display: false
        },
        cutoutPercentage: 30,
      },
    });
            
					} });
    });
    
	</script>
</body>

</html>
<?php
}

else{
	
	header("location:index.php");
}
?>