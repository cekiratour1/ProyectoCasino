<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="vermesajuego.php">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">ChrisSL</div>
      </a>

      <hr class="sidebar-divider my-0">
      <li class="nav-item">
        <a class="nav-link" href="index.html">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>
      <hr class="sidebar-divider">
      <li class="nav-item">
        <a class="nav-link" href="charts.php">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>Reportes G</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="vermesajuego.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Ver Mesa juego</span></a>
	  </li>
	   <li class="nav-item">
        <a class="nav-link" href="verfill.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Ver Fill</span></a>
	  </li>
	  <!-- inicio modifique -->
	  <li class="nav-item">
	  	<a href="nuevoreporte.php" class="nav-link">
			<span class="icon text-white-50">
				<i class="fas fa-flag"></i>
			</span>
			<span class="text">Nuevo reporte</span>
		</a>
      </li>
      <li class="nav-item">
	 	 <a href="agregarmesa.php" class="nav-link">
			<span class="icon text-white-50">
				<i class="fas fa-flag"></i>
			</span>
			<span class="text">Nueva mesa</span>
		</a>
	  </li>
	  <li class="nav-item">
	  	<a href="fill.php" class="nav-link">
			<span class="icon text-white-50">
				<i class="fas fa-flag"></i>
			</span>
			<span class="text">Nuevo fill</span>
		</a>
	  </li>	
	 
	  <!-- fin modifique -->
      <hr class="sidebar-divider d-none d-md-block">
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>
    </ul>