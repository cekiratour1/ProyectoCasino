<?php 
    $mysqli = new mysqli("localhost","root","","chrissb");
    /* verificar la conexión */
    if ($mysqli->connect_errno) {
        printf("Conexión fallida: %s\n", $mysqli->connect_error);
        exit();
    }

    $idmesa = $_GET["search"];
    $array = array();
	
	if(isset($_GET["search"])){
        $consulta = "select * from vw_new_reporte where id_MesaJuego ='".$idmesa."' ";
        if ($resultado = $mysqli->query($consulta)) {
            $resul = $resultado->fetch_assoc();
            echo json_encode($resul);
        }
    }

	if(isset($_GET["pie"])){
        $mes = 5;
        $consulta = "select * from vw_dashboard_pie";
        if ($resultado = $mysqli->query($consulta)) {
            // $resul = $resultado->fetch_assoc();
            while($row = $resultado->fetch_assoc()){
                $registros[$i]= $row;
                $i++;
            };
            // echo json_encode( array('data' => $registros ) );
            echo json_encode($registros);
        }
    }

    if(isset($_GET["bar"])){
        $mes = 5;
        $consulta = "select id_reportemesa, id_mesaJuego, efectivod, efectivou,marcad, marcau, Fecha,  filld, fillu, bancad,bancau from reportemesajuego	 where fecha < '2020-04-26 12:00:00' OR fecha > '2020-05-02 23:30:00' ORDER BY  efectivod desc, efectivou desc";        
        if ($resultado = $mysqli->query($consulta)) {
            $resul = $resultado->fetch_assoc();
            echo json_encode($resul);
        }
    }

?>