<?php 

	include ("conexion.php");
	session_start();
	
	if(isset($_SESSION["user"])){
		header("Location:vermesajuego.php");
	}
	$con = conectar();
	$user=$_POST["user"];
	$pass=$_POST["pass"];
	$rol;
	
	if(isset($_POST["user"])){
	$sql = mysqli_query($con,"select * from usuario where nombreUsuario ='".$user."' or email='".$user."' and pass ='".$pass."' ");
	$result = mysqli_num_rows($sql);
	
	while($filas = mysqli_fetch_array($sql)){		
			$_SESSION['user'] = $filas['nombreUsuario'];
			$rol = $filas['roles'];
					}	
					
	if($result == 1)
	{
		if($rol=='1')
		{
			
			$_SESSION['validacion'] = 1;
			header("Location:blank.php");
		}
		else{
		$_SESSION['validacion'] = 1;
		header("Location:vermesajuego.php");
		}
	}
	else if($result == 0)
	{
		echo "Usuario o contraseña no son validos";
		header("Location:index.php");
		$_SESSION['validacion'] = 0;
	}
  }
?>