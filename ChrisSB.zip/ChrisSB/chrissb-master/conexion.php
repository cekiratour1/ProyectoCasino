<?php
function conectar(){
	$con=mysqli_connect("127.0.0.1","root","tito10","chrissb");
	mysqli_query($con,"SET NAME 'utf8'");
	return $con;	
}
