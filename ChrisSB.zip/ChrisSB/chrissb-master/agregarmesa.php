
<!DOCTYPE html>
<?php
session_start();
if($_SESSION['validacion'] == 1)
{

			include("conexion.php");
			$con= conectar();
			$sql="SELECT id_banca from banca";
			$result=mysqli_query($con,$sql);
		?>
<html lang="es">
	<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
	<link rel="icon" type="image/png" href="../img/tarjetas.png" />
  <title>Cekira</title>
  <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="../css/sb-admin-2.min.css" rel="stylesheet">
</head>
<body id="page-top">
  <div id="wrapper">
  	<?php include("menu.php"); ?>
    <div id="content-wrapper" class="d-flex flex-column">
      <!-- Main Content -->
      <div id="content">
          <!-- Topbar -->
		  <?php include("header_logout.php"); ?>
        <div class="container-fluid">
		
		<form method="post" >
			<div class="form-group">
				<label for="exampleInputEmail1">Nombre de la mesa</label>
				<input name="mesa" type="text"  placeholder="Escriba por favor..." class="form-control" aria-describedby="emailHelp" required>    			
			</div>
			<div class="form-group">
				<label for="cars">Seleccione una banca:</label>
				<select name="bank" id="bank" class="form-control">
					<option value="0">Seleccione una opción:</option>
				  	  <?php
					while($filas = mysqli_fetch_array($result)){		
					echo '<option value="'.$filas[id_banca].'">'.$filas[id_banca].'</option>';
					}				
				?>
				</select>
			</div>
			<div class="form-check">
				<a href="vermesajuego.php" class="btn btn-danger btn-icon-split">
					<span class="icon text-white-50">
					<i class="fas fa-trash"></i>
					</span>
					<span class="text">Regresar</span>
				</a>
				<button type="submit" class="btn btn-success btn-icon-split">
						<span class="icon text-white-50">		  
						<i class="fas fa-check"></i>
                    	</span>
						<span class="text">Agregar</span>
				</button>
			</div>			
		</form>
		
		<?php			
			if(isset($_POST['mesa'])){
					$mesa=$_POST['mesa'];
					$bank=$_POST['bank'];
					$sql = "insert into mesajuego(nombre,id_banca)values('".$mesa."','".$bank."')";
				mysqli_query($con,$sql);
				// header("location:vermesajuego.php");
				echo '<script>window.location="vermesajuego.php"</script>';	
			}				
		?>
        </div>
      </div>

	  <?php include("footer.php"); ?>

    </div>
  </div>
  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <?php include("footer_logout.php"); ?>

  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="../js/sb-admin-2.min.js"></script>

</body>
</html>
<?php
}

else{
	
	header("location:index.php");
}
?>