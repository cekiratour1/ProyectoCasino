// Set new default font family and font color to mimic Bootstrap's default styling
Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
Chart.defaults.global.defaultFontColor = '#858796';

// Pie Chart Example
var ctx = document.getElementById("pie-chart");
var myPieChart = new Chart(ctx, {
  type: 'pie',
  data: {
    labels: ["Enero", "Febrero", "Marzo","Abril", "Mayo", "Junio","Julio", "Agosto", "Septiembre","Octubre", "Noviembre", "Diciembre"],
    datasets: [{
      data: [5, 10, 15,20,25,30,35,40,45,50,55,60],
      backgroundColor: ['#14ADEA', '#0A5471', '#36b9cc','#B21EA4','#5B08EC','#09A0C6','#13CA3A','#9FE116','#E1DB16','#D07F0B','#D03E0B','#EC150E'],
      hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf','#500849','#362650','#324A50','#065D18','#486805','#6D6A09','#6D4409','#5D2410','#64201D'],
      hoverBorderColor: "rgba(234, 236, 244, 1)",
    // },
    // {
    //     data: [65, 40, 25],
    //     backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc'],
    //     hoverBackgroundColor: ['#0AD877', '#0B7E48', '#2c9faf'],
    //     hoverBorderColor: "rgba(234, 236, 244, 1)",
      }
    ],
  },
  options: {
    maintainAspectRatio: false,
    tooltips: {
      backgroundColor: "rgb(255,255,255)",
      bodyFontColor: "#858796",
      borderColor: '#dddfeb',
      borderWidth: 1,
      xPadding: 15,
      yPadding: 15,
      displayColors: false,
      caretPadding: 10,
    },
    legend: {
      display: false
    },
    cutoutPercentage: 30,
  },
});
