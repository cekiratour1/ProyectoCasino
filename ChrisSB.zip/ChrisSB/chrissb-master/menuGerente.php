<!DOCTYPE html>
<html>
	<head>
		
	</head>
	<body>
		<ul>Banca:
			<li><a href="#">Actualizar banca</a></li>
			<li><a href="#">Crear nueva banca</a></li>
			<li><a href="#">Eliminar banca</a></li>
		</ul>
		<br>
		<ul>Mesa de juego:
			<li><a href="#">Editar mesa de juego</a></li>
			<li><a href="#">Crear mesa de juego</a></li>
			<li><a href="#">Eliminar mesa de juego</a></li>
		</ul>
		<br>
		<ul>Reportes:
			<li>
				<ul>Editar:
					<li><a href="#">reporteMesa</a></li>
					<li><a href="#">reporteDia</a></li>
					<li><a href="#">reporteSemana</a></li>
				</ul>
			</li>
			<br>
			<li>
				<ul>Crear:
					<li><a href="#">reporteMesa</a></li>
					<li><a href="#">reporteDia</a></li>
					<li><a href="#">reporteSemana</a></li>
				</ul>
			</li>
			<br>
			<li>
				<ul>Eliminar:
					<li><a href="#">reporteMesa</a></li>
					<li><a href="#">reporteDia</a></li>
					<li><a href="#">reporteSemana</a></li>
				</ul>
			</li>
		</ul>
		<br>
		<ul>Ver estado:
			<li><a href="#">Mesa juego</a></li>
			<li><a href="#">Dias</a></li>
			<li><a href="#">Semanas</a></li>
		</ul>
	</body>
</html>