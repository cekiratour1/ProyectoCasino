
<!DOCTYPE html>
<?php	
session_start();
if($_SESSION['validacion'] == 1)//para validar que la session este iniciada
{	
?>
<html>
	<head>
	<link rel="icon" type="image/png" href="../img/tarjetas.png" />
		<link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="../css/sb-admin-2.min.css" rel="stylesheet">
  <script src="../vendor/jquery/jquery.min.js">	</script>
	</head>
	<body>
	<div id="wrapper">
		<?php
			include("conexion.php");
			$con= conectar();
			$sql="SELECT * from mesajuego order by nombre asc";
			$result=mysqli_query($con, $sql);

		include("menu.php"); 
		?>
    <div id="content-wrapper" class="d-flex flex-column">
      <!-- Main Content -->
      <div id="content">
		  <!-- inicio modifique -->
          <!-- Topbar -->
		  <?php include("header_logout.php"); ?>
		<div class="container">
	<div class="col-xl-10 col-lg-9 col-md-8">
    <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-5">
        <!-- Nested Row within Card Body -->
        <div class="row">
		
          <div class="col-lg-12">
            <div class="p-0">
             
                <h1 class="h4 text-gray-900 mb-4">Nuevo Reporte</h1>
              </div>
              <form class="user" method="post">
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
	<label for="cars">Select mesajuego:</label>
				  <select id="idmesa" name="idmesa" class="custom-select">
					<option value="0">Seleccione:</option>
				  	 <?php
						while($filas = mysqli_fetch_array($result)){		
						echo '<option value="'.$filas[id_MesaJuego].'">'.$filas[nombre].'</option>';
					}?>
				</select>
					<br><br>	
				<input name="Dviva" type="number" required class="form-control form-control-user" placeholder="Banca_final_Dop"><br>
				<input name="Uviva" type="number" required class="form-control form-control-user" placeholder="Banca_final_US"><br>
				<input name="edop" type="number" class="form-control form-control-user" placeholder="Efectivo Dop"><br>
				<input name="eusa" type="number"class="form-control form-control-user" placeholder="Efectivo US"><br>
				<input name="Mdop" type="number"class="form-control form-control-user" placeholder="Marca Dop"><br>
				<input name="Musa" type="number"class="form-control form-control-user" placeholder="Marca US"><br>
				<input name="Fdop" type="number"class="form-control form-control-user" placeholder="Fill Dop"><br>
				<input name="Fusa" type="number"class="form-control form-control-user" placeholder="Fill US">
				<br>
				<input type="submit"  value="guardar" class="btn btn-primary btn-user btn-block">
				<a href="vermesajuego.php" class="btn btn-primary btn-user btn-block">Regresar</a>
                </div>
            </div>
			</form>
          </div>
        </div>
    </div>
  </div>
  </div>
  </div>
  </div>
<?php
$a = "Hola Mundo!";
	if(isset($_POST['idmesa'])){
					$idmesa= $_POST['idmesa'];
					var_dump($idmesa);
					$Dviva = $_POST['Dviva'];
					$Uviva = $_POST['Uviva'];
					$Edop = $_POST['edop'];
					$Eusa = $_POST['eusa'];
					$Mdop = $_POST['Mdop'];
					$Musa = $_POST['Musa'];
					$Fdop = $_POST['Fdop'];
					$Fusa = $_POST['Fusa'];
					$sql2 = "insert into reportemesajuego (id_mesaJuego,efectivod,efectivou,marcad,marcau,filld,fillu,bancad,bancau)values('".$idmesa."','".$Edop."','".$Eusa."','".$Mdop."','".$Musa."','".$Fdop."','".$Fusa."','".$Dviva."','".$Uviva."')";
				mysqli_query($con,$sql2);
				echo '<script>window.location="vermesajuego.php"</script>';	
			}	
			include("footer.php");		
			include("footer_logout.php");
			?>
			<script type="text/javascript">			
				$("[name='idmesa']").on('change', function(){
					$.ajax({
					url:   'search.php?search='+$(this).val(),
					type:  'get',
					success:  function (data) {
						// var result = eval("("+data+")");
						var result = JSON.parse(data);
						$("[name='Dviva']").val(result.dineroDOP);
						$("[name='Uviva']").val(result.dineroUS);
						$("[name='Fdop']").val(result.fill_dineroDOP);
						$("[name='Fusa']").val(result.fill_dineroUS);
					} });
				});			
			</script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="../js/sb-admin-2.min.js"></script>
	</body>
</html>
<?php
}
else{
	
	header("location:index.php");
}
?>