<!DOCTYPE html>
<?php
session_start();
if($_SESSION['validacion'] == 1)
{
?>
<html>
	<head>
		
  <!-- Custom fonts for this template-->
  <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
	<link rel="icon" type="image/png" href="../img/tarjetas.png" />
  <!-- Custom styles for this template-->
  <link href="../css/sb-admin-2.min.css" rel="stylesheet">
	</head>
	<body class="bg-gradient-light">
	<?php
			include("conexion.php");
			$con= conectar();
			$sql="SELECT * from mesajuego order by id_mesajuego asc";
			$result=mysqli_query($con, $sql);
		?>
		 <div id="wrapper">
   <?php include("menu.php")?>
    <div id="content-wrapper" class="d-flex flex-column">
      <!-- Main Content -->
      <div id="content">
		  <!-- inicio modifique -->
          <!-- Topbar -->
		 <?php include("header_logout.php"); ?>
		<div class="container">
	<div class="col-xl-10 col-lg-9 col-md-8">
    <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-5">
        <!-- Nested Row within Card Body -->
        <div class="row">
		
          <div class="col-lg-12">
            <div class="p-0">
             
                <h1 class="h4 text-gray-900 mb-4">Fill</h1>
              </div>
              <form class="user" method="post">
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <label for="cars">Select banca:</label>
				  <select name="juego" class="custom-select">
					<option value="0">Seleccione:</option>
				  	  <?php
					while($filas = mysqli_fetch_array($result)){		
					echo '<option value="'.$filas[id_MesaJuego].'">'.$filas[nombre].'</option>';
					}				
				?>
				</select><br><br>
				<div class="form-group">
				<input name="Dviva" type="number" class="form-control form-control-user" placeholder="Monto dop vivas"> <br><br>
				<input name="Dcredi" type="number"class="form-control form-control-user" placeholder="Monto dop credito"> <br><br>
				<input name="Uviva" type="number" class="form-control form-control-user" placeholder="Monto us vivas"> <br><br>
				<input name="Ucredi" type="number"class="form-control form-control-user" placeholder="Monto us vivas"> <br><br>
			<input type="submit" name="inicial" value="Agregar" class="btn btn-primary btn-user btn-block">
			</div>
			<br>
			<a href="vermesajuego.php" class="btn btn-google btn-user btn-block">Regresar</a>
			<br>
                </div>
             
        
            </div>
			</form>
          </div>
        </div>
    </div>
  </div>
  </div>
  </div>
		<?php
		include("footer.php");		
		include("footer_logout.php");

		
			if(isset($_POST['juego'])){
					$mesa=$_POST['juego'];
					$Dviva=$_POST['Dviva'];
					$Dcredi=$_POST['Dcredi'];
					$Uviva=$_POST['Uviva'];
					$Ucredi=$_POST['Ucredi'];
					$sql2 = "insert into fill(id_mesajuego,dopVivas,dopCredito,usVivas,usCredito)values('".$mesa."','".$Dviva."','".$Dcredi."','".$Uviva."','".$Ucredi."')";
				mysqli_query($con,$sql2);
					echo '<script>window.location="vermesajuego.php"</script>';
			}			
		?>
		<script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="../js/sb-admin-2.min.js"></script>
	</body>
</html>
<?php
}
else{
	header("location:index.php");
}
?>
